package com.entity.layer4;

	


	
import com.entity.layer1.Logindetail;
import com.entity.layer3.Logindatadto;

	public interface LoginService {
		String registerUser(Logindatadto user);
		Logindetail loginUser(String userId, String password) throws Exception;
		int getInvalidAttempts(String UserId);
		String resetPassword(String userId, String updatedPassword) throws Exception;
		String getUserId(String accNumber);
		String resetTransactionPassword(String userId, String updatedPassword);
	}



