package com.entity.layer3;

public class Logindatadto {
	
	private String accNumber;
	private String loginPassword;
	private String transactionnPassword;
	public String getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
	public String getLoginPassword() {
		return loginPassword;
	}
	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
	public String getTransactionnPassword() {
		return transactionnPassword;
	}
	public void setTransactionnPassword(String transactionnPassword) {
		this.transactionnPassword = transactionnPassword;
	}
	

}
