package com.entity.layer3;

public class PayeedetailDTO {

	private String userAcNumber;
//	public PayeedetailDTO() {
	//	super();
		// TODO Auto-generated constructor stub
//	}
	private String PayeeAcNumber;
	private String payeename;
	public String getUserAcNumber() {
		return userAcNumber;
	}
	public void setUserAcNumber(String userAcNumber) {
		this.userAcNumber = userAcNumber;
	}
	public String getPayeeAcNumber() {
		return PayeeAcNumber;
	}
	public void setPayeeAcNumber(String payeeAcNumber) {
		this.PayeeAcNumber = payeeAcNumber;
	}
	public String getPayeename() {
		return payeename;
	}
	public void setPayeename(String payeename) {
		this.payeename = payeename;
	}
	
}
	
	


